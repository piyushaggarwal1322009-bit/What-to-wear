'use client';

import { useState, useEffect } from 'react';
import { Situation, WeatherData, Recommendation } from '../types/weather';
import { getRecommendation } from '../logic/recommendationEngine';

const SITUATIONS: { label: string; value: Situation; icon: string }[] = [
  { label: 'College', value: 'College', icon: '🎓' },
  { label: 'Interview', value: 'Interview', icon: '💼' },
  { label: 'Wedding', value: 'Wedding', icon: '💍' },
  { label: 'Gym', value: 'Gym', icon: '🏋️' },
  { label: 'Outdoor Event', value: 'Outdoor Event', icon: '🌳' },
];

export default function Home() {
  const [situation, setSituation] = useState<Situation>('College');
  const [location, setLocation] = useState('');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [recommendation, setRecommendation] = useState<Recommendation | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchWeather = async () => {
    if (!location) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/weather?location=${encodeURIComponent(location)}`);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Weather unavailable');
      }
      const data = await res.json();
      setWeather(data);
    } catch (err: any) {
      setError(err.message || 'Connection problem');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (weather) {
      setRecommendation(getRecommendation(weather, situation));
    }
  }, [weather, situation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchWeather();
  };

  return (
    <main className="max-w-4xl mx-auto p-4 md:p-8 space-y-8">
      <header className="text-center py-8">
        <h1 className="text-4xl font-bold mb-2">What Should I Wear?</h1>
        <p className="text-gray-600">Dress for the weather, not just the forecast.</p>
      </header>

      <section className="bg-white p-6 rounded-2xl shadow-sm border space-y-6">
        <div>
          <h2 className="text-lg font-semibold mb-3">1. Select Situation</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {SITUATIONS.map((s) => (
              <button
                key={s.value}
                onClick={() => setSituation(s.value)}
                className={`p-4 rounded-xl flex flex-col items-center gap-2 transition-all ${
                  situation === s.value
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                }`}
              >
                <span className="text-2xl">{s.icon}</span>
                <span className="text-sm font-medium">{s.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-3">2. Enter Location</h2>
          <form onSubmit={handleSubmit} className="flex gap-2 max-w-md">
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Enter your city... (e.g. Delhi)"
              className="flex-1 p-3 border rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading || !location}
              className="bg-black text-white px-6 py-3 rounded-xl font-medium hover:bg-gray-800 disabled:opacity-50"
            >
              Get Recommendation →
            </button>
          </form>
        </div>
      </section>

      {loading && (
        <div className="text-center py-12 animate-pulse space-y-4">
          <div className="text-4xl">🌦️</div>
          <p className="text-gray-600 font-medium">Checking the weather...</p>
          <p className="text-sm text-gray-500">Finding the best recommendation for your situation.</p>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 p-6 rounded-xl text-center">
          <h3 className="font-semibold mb-2">⚠️ {error}</h3>
          <p className="text-sm mb-4">Please check your internet connection and try again.</p>
          <button
            onClick={fetchWeather}
            className="px-4 py-2 bg-white rounded shadow-sm hover:bg-gray-50 text-sm font-medium"
          >
            Try Again
          </button>
        </div>
      )}

      {weather && recommendation && !loading && !error && (
        <section className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border flex flex-col md:flex-row justify-between items-center gap-4">
            <div>
              <div className="text-sm text-gray-500 font-medium">LOCATION & SITUATION</div>
              <div className="text-xl font-bold">📍 {weather.location} • {SITUATIONS.find(s => s.value === situation)?.icon} {situation}</div>
            </div>
            <div className="flex gap-6 text-sm text-gray-600 bg-gray-50 p-4 rounded-xl">
              <div>
                <div className="font-semibold text-lg text-black">{weather.temperature}°C</div>
                <div>Feels {weather.feelsLike}°C</div>
              </div>
              <div>
                <div className="font-semibold text-black">{weather.rainProbability}%</div>
                <div>Rain</div>
              </div>
              <div>
                <div className="font-semibold text-black">{weather.humidity}%</div>
                <div>Humidity</div>
              </div>
              <div>
                <div className="font-semibold text-black">{weather.windSpeed} km/h</div>
                <div>Wind</div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-blue-50 border border-blue-100 p-6 rounded-2xl">
              <h3 className="text-blue-800 font-bold text-lg mb-4 flex items-center gap-2">👕 WHAT TO WEAR</h3>
              <ul className="space-y-2">
                {recommendation.wear.map((item, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-blue-500 mt-1">•</span>
                    <span className="font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-2xl">
              <h3 className="text-indigo-800 font-bold text-lg mb-4 flex items-center gap-2">☂️ WHAT TO CARRY</h3>
              {recommendation.carry.length > 0 ? (
                <ul className="space-y-2">
                  {recommendation.carry.map((item, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-indigo-500 mt-1">•</span>
                      <span className="font-medium">{item}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-500 italic">Nothing extra needed.</p>
              )}
            </div>

            <div className="bg-red-50 border border-red-100 p-6 rounded-2xl">
              <h3 className="text-red-800 font-bold text-lg mb-4 flex items-center gap-2">⚠️ WHAT TO AVOID</h3>
              {recommendation.avoid.length > 0 ? (
                <ul className="space-y-2">
                  {recommendation.avoid.map((item, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span className="font-medium">{item}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-500 italic">Nothing specific to avoid.</p>
              )}
            </div>
          </div>

          <div className="bg-gray-900 text-white p-6 rounded-2xl">
            <h3 className="font-bold text-lg mb-3 flex items-center gap-2">💡 WHY?</h3>
            <div className="space-y-2 text-gray-300">
              {recommendation.reasons.map((reason, i) => (
                <p key={i}>{reason}</p>
              ))}
            </div>
          </div>
        </section>
      )}
    </main>
  );
}
